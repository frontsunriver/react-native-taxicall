export const features =  {
    AllowCriticalEditsAdmin:true,
    AllowCountrySelection:true,
    WebsitePagesEnabled:true,
    MobileLoginEnabled:true,
    FacebookLoginEnabled:true,
    AppleLoginEnabled:true
};